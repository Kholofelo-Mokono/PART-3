// Hamburger toggle
document.addEventListener("DOMContentLoaded", () => {
    const hamburger = document.getElementById("hamburger");
    const navMenu = document.getElementById("navMenu");
    
    hamburger.addEventListener("click", () => {
        navMenu.classList.toggle("active");
    });
});

function validateForm() {
    let isValid = true;

    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const message = document.getElementById("message");

// Clear previous errors 
document.getElementById("nameError").textContent = "";
document.getElementById("emailError").textContent = "";
document.getElementById("messageError").textContent = "";

// Name validation 
if (name.value.trim() === "") {
    document.getElementById("nameError").textContent = "Name is required.";
    isValid = false;
}

// Email validation
const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
if (email.value.trim() === "") {
    document.getElementById("emailerror").textContent = "Email is required.";
    isValid = false;
} else if (!email.value.match(emailPattern)) {
    document.getElementById("emailError").textContent = "Please enter a vaild email."
    isValid = false;
}

// Message validation
if (message.value.trim() === "") {
    document.getElementById("messageError").textContent = "Message cannot be empty.";
    isValid = false;
}

return isValid
}

function updateDateTime() {
    const now = new Date();
    const dateTimeString = now.toLocaleString();
    document.getElementById("dateTime").innerHTML = "Current Date & Time:" + dateTimeString;
}

// Update immediately and every second 
updateDateTime();
setInterval(updateDateTime, 1000);