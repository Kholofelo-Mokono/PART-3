// Hamburger toggle
document.addEventListener("DOMContentLoaded", () => {
    const hamburger = document.getElementById("hamburger");
    const navMenu = document.getElementById("navMenu");
    
    hamburger.addEventListener("click", () => {
        navMenu.classList.toggle("active");
    });
});

function updateDateTime() {
    const now = new Date();
    const dateTimeString = now.toLocaleString();
    document.getElementById("dateTime").innerHTML = "Current Date & Time:" + dateTimeString;
}

// Update immediately and every second 
updateDateTime();
setInterval(updateDateTime, 1000);